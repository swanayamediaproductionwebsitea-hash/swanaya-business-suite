const STORAGE_KEY = "swanyaPortalState";
const ADMIN_PASSWORD = "AADITHYAN MENON";

const seedStaff = [
  {
    id: "staff-1",
    name: "Ananya Menon",
    username: "ananya",
    email: "ananya@swanyamedia.in",
    phone: "+91 90000 11111",
    role: "Content Strategist",
    status: "approved",
    registeredAt: new Date().toISOString()
  },
  {
    id: "staff-2",
    name: "Rahul Nair",
    username: "rahul",
    email: "rahul@swanyamedia.in",
    phone: "+91 90000 22222",
    role: "Video Editor",
    status: "approved",
    registeredAt: new Date().toISOString()
  }
];

let state = loadState();
normalizeState();
let currentUser = null;
let currentPage = "dashboard";
let selectedStaffId = state.staff.find((person) => person.status === "approved")?.id || null;

const pages = {
  dashboard: document.getElementById("dashboardPage"),
  attendance: document.getElementById("attendancePage"),
  performance: document.getElementById("performancePage"),
  content: document.getElementById("contentPage"),
  spotify: document.getElementById("spotifyPage"),
  settings: document.getElementById("settingsPage")
};

const navByRole = {
  admin: [
    ["dashboard", "Mothership"],
    ["attendance", "Attendance"],
    ["performance", "Performance"],
    ["content", "Content Lab"],
    ["spotify", "Spotify"],
    ["settings", "Settings"]
  ],
  staff: [
    ["dashboard", "Dashboard"],
    ["attendance", "Attendance"],
    ["performance", "Performance"],
    ["content", "Content Lab"],
    ["spotify", "Spotify"]
  ]
};

function loadState() {
  const stored = localStorage.getItem(STORAGE_KEY);
  if (stored) return JSON.parse(stored);

  const today = new Date();
  const state = {
    staff: seedStaff,
    attendance: [],
    settings: {
      adminPassword: ADMIN_PASSWORD,
      companyName: "SWANAYA MEDIA ENTERPRISES",
      workingDays: "Mon-Sat",
      lowAttendanceThreshold: 75,
      logoDataUrl: "",
      subAdmins: []
    }
  };

  for (const person of seedStaff) {
    for (let day = 1; day <= today.getDate(); day += 1) {
      const date = toDateKey(new Date(today.getFullYear(), today.getMonth(), day));
      state.attendance.push({
        staffId: person.id,
        date,
        status: person.id === "staff-1" ? "present" : day % 6 === 0 ? "absent" : "present"
      });
    }
  }

  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  return state;
}

function normalizeState() {
  state.settings = state.settings || {};
  state.settings.adminPassword = state.settings.adminPassword || ADMIN_PASSWORD;
  state.settings.companyName = state.settings.companyName || "SWANAYA MEDIA ENTERPRISES";
  state.settings.workingDays = state.settings.workingDays || "Mon-Sat";
  state.settings.lowAttendanceThreshold = state.settings.lowAttendanceThreshold || 75;
  state.settings.logoDataUrl = state.settings.logoDataUrl || "";
  state.settings.subAdmins = state.settings.subAdmins || [];
  saveState();
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function $(selector) {
  return document.querySelector(selector);
}

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function toDateKey(date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function monthDays() {
  const now = new Date();
  return new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
}

function monthDate(day) {
  const now = new Date();
  return toDateKey(new Date(now.getFullYear(), now.getMonth(), day));
}

function dateForMonthDay(day) {
  const now = new Date();
  return new Date(now.getFullYear(), now.getMonth(), day);
}

function isWorkingDate(date) {
  const day = date.getDay();
  if (state.settings.workingDays === "Mon-Fri") return day !== 0 && day !== 6;
  return day !== 0;
}

function approvedStaff() {
  return state.staff.filter((person) => person.status === "approved");
}

function attendanceFor(staffId) {
  const days = monthDays();
  const records = new Map(state.attendance.filter((item) => item.staffId === staffId).map((item) => [item.date, item.status]));
  let present = 0;
  let absent = 0;
  let promoted = 0;
  let workingDays = 0;

  for (let day = 1; day <= days; day += 1) {
    if (!isWorkingDate(dateForMonthDay(day))) continue;
    workingDays += 1;
    const status = records.get(monthDate(day));
    if (status === "present") present += 1;
    if (status === "absent") absent += 1;
    if (status === "promoted") promoted += 1;
  }

  const scored = present + promoted;
  return {
    present,
    absent,
    promoted,
    workingDays,
    percentage: Math.round((scored / workingDays) * 100),
    full: scored === workingDays
  };
}

function setNotice(message) {
  $("#authNotice").textContent = message;
}

function pulseLogin() {
  const panel = $("#authPanel");
  panel.classList.add("login-pulse");
  setTimeout(() => panel.classList.remove("login-pulse"), 460);
}

function setAuthTab(tabName) {
  document.querySelectorAll("[data-auth-tab]").forEach((tab) => tab.classList.toggle("active", tab.dataset.authTab === tabName));
  document.querySelectorAll(".auth-form").forEach((form) => form.classList.remove("active"));
  const formId = tabName === "admin" ? "adminLogin" : tabName === "staff" ? "staffLogin" : "registerForm";
  document.getElementById(formId).classList.add("active");
  setNotice("");
}

function login(role, user = null) {
  currentUser = role === "admin" ? { accessRole: "admin", name: user?.name || "Admin" } : { ...user, accessRole: "staff" };
  currentPage = "dashboard";
  selectedStaffId = role === "staff" ? user.id : selectedStaffId || approvedStaff()[0]?.id || null;
  $("#authView").classList.add("hidden");
  $("#portalView").classList.remove("hidden");
  $("#roleLabel").textContent = role === "admin" ? "Admin Control" : user.role;
  $("#sidebarTitle").textContent = role === "admin" ? "Mothership Panel" : user.name;
  renderNav();
  applyLogo();
  renderPage("dashboard");
}

function logout() {
  currentUser = null;
  $("#portalView").classList.add("hidden");
  $("#authView").classList.remove("hidden");
  setAuthTab("admin");
}

function renderNav() {
  const nav = $("#navLinks");
  nav.innerHTML = "";
  navByRole[currentUser.accessRole].forEach(([id, label]) => {
    const button = el("button", id === currentPage ? "active" : "", label);
    button.type = "button";
    button.addEventListener("click", () => renderPage(id));
    nav.append(button);
  });
}

function renderPage(id) {
  currentPage = id;
  Object.entries(pages).forEach(([pageId, page]) => page.classList.toggle("active", pageId === id));
  $("#pageTitle").textContent = {
    dashboard: currentUser.accessRole === "admin" ? "Mothership Panel" : "Staff Dashboard",
    attendance: "Attendance Calendar",
    performance: "Performance File",
    content: "Content Lab",
    spotify: "Spotify Connector",
    settings: "Rules & Settings"
  }[id];
  renderNav();
  const renderer = {
    dashboard: renderDashboard,
    attendance: renderAttendance,
    performance: renderPerformance,
    content: renderContentLab,
    spotify: renderSpotify,
    settings: renderSettings
  }[id];
  renderer();
}

function renderDashboard() {
  const page = pages.dashboard;
  const approved = approvedStaff();
  const pending = state.staff.filter((person) => person.status === "pending");
  const today = toDateKey(new Date());
  const presentToday = new Set(state.attendance.filter((item) => item.date === today && item.status !== "absent").map((item) => item.staffId)).size;
  const absentToday = Math.max(approved.length - presentToday, 0);

  if (currentUser.accessRole === "staff") {
    const stats = attendanceFor(currentUser.id);
    page.innerHTML = `
      <div class="metric-grid">
        ${metric("Attendance", `${stats.percentage}%`, stats.percentage < state.settings.lowAttendanceThreshold ? "low-warning" : "")}
        ${metric("Present", stats.present)}
        ${metric("Absent", stats.absent)}
        ${metric("Promoted", stats.promoted)}
      </div>
      <div class="panel ${stats.full ? "full-attendance" : ""}">
        <div class="panel-header">
          <div><h2>${currentUser.name}</h2><p>${currentUser.role} · ${currentUser.email}</p></div>
          <span class="status-pill">${stats.full ? "Full Attendance" : "Active"}</span>
        </div>
        <div class="progress" aria-label="Attendance percentage"><span style="--value:${stats.percentage}%"></span></div>
      </div>
    `;
    return;
  }

  page.innerHTML = `
    <div class="metric-grid">
      ${metric("Total Staff", approved.length)}
      ${metric("Present Today", presentToday)}
      ${metric("Absent Today", absentToday)}
      ${metric("Pending", pending.length)}
    </div>
    <div class="panel">
      <div class="panel-header"><h2>Approval Queue</h2><span class="status-pill">${pending.length} waiting</span></div>
      <div class="approval-list" id="approvalList"></div>
    </div>
    <div class="panel">
      <div class="panel-header"><h2>Staff Directory</h2><input id="staffSearch" type="search" placeholder="Search staff" /></div>
      <div class="staff-list" id="staffList"></div>
    </div>
  `;

  renderApprovals();
  renderStaffList();
  $("#staffSearch").addEventListener("input", renderStaffList);
}

function metric(label, value, extra = "") {
  return `<article class="metric-card ${extra}"><span>${label}</span><strong>${value}</strong></article>`;
}

function renderApprovals() {
  const list = $("#approvalList");
  const pending = state.staff.filter((person) => person.status === "pending");
  list.innerHTML = "";
  if (!pending.length) {
    list.append(el("p", "", "No pending registrations."));
    return;
  }
  pending.forEach((person) => {
    const row = el("div", "approval-row");
    row.innerHTML = `<div><strong>${person.name}</strong><p>${person.role} · ${person.username}</p></div>`;
    const actions = el("div", "row-actions");
    const approve = el("button", "primary", "Approve");
    const reject = el("button", "danger", "Reject");
    approve.addEventListener("click", () => updateStaffStatus(person.id, "approved"));
    reject.addEventListener("click", () => updateStaffStatus(person.id, "rejected"));
    actions.append(approve, reject);
    row.append(actions);
    list.append(row);
  });
}

function updateStaffStatus(id, status) {
  state.staff = state.staff.map((person) => (person.id === id ? { ...person, status } : person));
  if (!selectedStaffId && status === "approved") selectedStaffId = id;
  saveState();
  renderDashboard();
}

function renderStaffList() {
  const list = $("#staffList");
  const query = ($("#staffSearch")?.value || "").toLowerCase();
  list.innerHTML = "";
  state.staff
    .filter((person) => `${person.name} ${person.username} ${person.role}`.toLowerCase().includes(query))
    .forEach((person) => {
      const row = el("div", "approval-row");
      row.innerHTML = `<div><strong>${person.name}</strong><p>${person.role} · ${person.email} · ${person.phone}</p></div>`;
      const actions = el("div", "row-actions");
      const status = el("span", "status-pill", person.status);
      const remove = el("button", "danger", "Remove");
      remove.type = "button";
      remove.addEventListener("click", () => removeStaff(person.id));
      actions.append(status, remove);
      row.append(actions);
      list.append(row);
    });
}

function removeStaff(id) {
  const person = state.staff.find((item) => item.id === id);
  if (!person) return;
  const confirmed = window.confirm(`Remove ${person.name} from the portal? Their attendance records will also be deleted.`);
  if (!confirmed) return;
  state.staff = state.staff.filter((item) => item.id !== id);
  state.attendance = state.attendance.filter((item) => item.staffId !== id);
  if (selectedStaffId === id) selectedStaffId = approvedStaff()[0]?.id || null;
  saveState();
  renderDashboard();
}

function renderAttendance() {
  const page = pages.attendance;
  const targetId = currentUser.accessRole === "staff" ? currentUser.id : selectedStaffId;
  const target = state.staff.find((person) => person.id === targetId);
  const options = approvedStaff().map((person) => `<option value="${person.id}" ${person.id === targetId ? "selected" : ""}>${person.name}</option>`).join("");
  page.innerHTML = `
    <div class="panel">
      <div class="panel-header">
        <div><h2>${target ? target.name : "No approved staff yet"}</h2><p>${currentUser.accessRole === "admin" ? "Click a date to cycle Present, Absent, Promoted, Blank." : "Read-only monthly attendance view."}</p></div>
        ${currentUser.accessRole === "admin" ? `<select id="staffPicker">${options}</select>` : ""}
      </div>
      <div id="calendar" class="calendar"></div>
    </div>
  `;
  if ($("#staffPicker")) {
    $("#staffPicker").addEventListener("change", (event) => {
      selectedStaffId = event.target.value;
      renderAttendance();
    });
  }
  renderCalendar(targetId);
}

function renderCalendar(staffId) {
  const calendar = $("#calendar");
  calendar.innerHTML = "";
  if (!staffId) return;
  const stats = attendanceFor(staffId);
  for (let day = 1; day <= monthDays(); day += 1) {
    const key = monthDate(day);
    const record = state.attendance.find((item) => item.staffId === staffId && item.date === key);
    const button = el("button", `day ${record?.status || ""} ${!isWorkingDate(dateForMonthDay(day)) ? "offday" : ""} ${currentUser.accessRole === "staff" ? "readonly" : ""} ${stats.full ? "full-attendance" : ""}`, String(day));
    button.type = "button";
    if (currentUser.accessRole === "admin") {
      button.title = "Click to change attendance";
      button.addEventListener("click", () => cycleAttendance(staffId, key));
    }
    calendar.append(button);
  }
}

function cycleAttendance(staffId, date) {
  const statuses = [undefined, "present", "absent", "promoted"];
  const index = state.attendance.findIndex((item) => item.staffId === staffId && item.date === date);
  const current = index >= 0 ? state.attendance[index].status : undefined;
  const next = statuses[(statuses.indexOf(current) + 1) % statuses.length];
  if (!next && index >= 0) state.attendance.splice(index, 1);
  if (next && index >= 0) state.attendance[index].status = next;
  if (next && index < 0) state.attendance.push({ staffId, date, status: next });
  saveState();
  renderAttendance();
}

function renderPerformance() {
  const page = pages.performance;
  const people = currentUser.accessRole === "staff" ? [currentUser] : approvedStaff();
  page.innerHTML = `<div class="performance-list"></div>`;
  const list = page.querySelector(".performance-list");
  people.forEach((person) => {
    const stats = attendanceFor(person.id);
    const row = el("article", `panel ${stats.full ? "full-attendance" : ""}`);
    row.innerHTML = `
      <div class="panel-header">
        <div><h2>${person.name}</h2><p>${person.role} · ${stats.present} present · ${stats.absent} absent · ${stats.promoted} promoted</p></div>
        <span class="status-pill">${stats.percentage}%</span>
      </div>
      <div class="progress"><span style="--value:${stats.percentage}%"></span></div>
      ${stats.percentage < state.settings.lowAttendanceThreshold ? `<p class="low-warning"><strong>Low attendance warning:</strong> below ${state.settings.lowAttendanceThreshold}% threshold.</p>` : ""}
    `;
    list.append(row);
  });
}

function renderContentLab() {
  const page = pages.content;
  page.innerHTML = `
    <div class="tool-grid">
      <div class="panel">
        <h2>Prompt</h2>
        <label>Content type
          <select id="contentType">
            <option>Social Media Post</option>
            <option>Blog</option>
            <option>Script</option>
            <option>Ad Copy</option>
          </select>
        </label>
        <label>Brief
          <textarea id="contentPrompt" placeholder="Describe the campaign, audience, offer, or idea..."></textarea>
        </label>
        <button id="generateContent" class="primary" type="button">Generate Mock Draft</button>
      </div>
      <div class="content-output" id="contentOutput">Your generated draft will appear here.</div>
    </div>
  `;
  $("#generateContent").addEventListener("click", () => {
    const type = $("#contentType").value;
    const prompt = $("#contentPrompt").value.trim() || "a fresh Swanya Media campaign";
    $("#contentOutput").textContent = mockContent(type, prompt);
  });
}

function mockContent(type, prompt) {
  const hooks = {
    "Social Media Post": "Stop the scroll with a crisp visual, a human line, and one action.",
    Blog: "Open with the problem, build trust with examples, and close with a clear next step.",
    Script: "Scene 1: a restless brand team. Scene 2: Swanya brings clarity. Scene 3: measurable momentum.",
    "Ad Copy": "Make the offer direct, the proof visible, and the call-to-action impossible to miss."
  };
  return `${type} Draft\n\n${hooks[type]}\n\nCampaign idea: ${prompt}\n\nVoice: confident, warm, visually sharp.\nCTA: Build your next media move with Swanya.`;
}

function renderSpotify() {
  pages.spotify.innerHTML = `
    <div class="spotify-frame">
      <div class="panel-header">
        <div><h2>Studio Ambience</h2><p>Embedded playback works in-browser. Full OAuth controls can be connected later with a Spotify Client ID.</p></div>
        <span class="status-pill">Embed Mode</span>
      </div>
      <iframe src="https://open.spotify.com/embed/playlist/37i9dQZF1DX4sWSpwq3LiO?utm_source=generator" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>
    </div>
  `;
}

function renderSettings() {
  if (currentUser.accessRole !== "admin") return;
  pages.settings.innerHTML = `
    <div class="panel">
      <h2>Portal Rules</h2>
      <div class="setting-row">
        <label>Working days
          <select id="workingDays"><option>Mon-Sat</option><option>Mon-Fri</option></select>
        </label>
        <label>Low attendance threshold
          <input id="threshold" type="number" min="1" max="100" value="${state.settings.lowAttendanceThreshold}" />
        </label>
        <button id="saveSettings" class="primary" type="button">Save Settings</button>
      </div>
      <p>Admin unlock password is set to <strong>AADITHYAN MENON</strong>.</p>
    </div>
    <div class="panel">
      <div class="panel-header">
        <div><h2>Logo Upload</h2><p>Upload a company logo for the login page and admin sidebar.</p></div>
        ${state.settings.logoDataUrl ? `<button id="removeLogo" class="danger" type="button">Remove Logo</button>` : ""}
      </div>
      <label>Choose logo image
        <input id="logoUpload" type="file" accept="image/*" />
      </label>
    </div>
    <div class="panel">
      <h2>Sub Admins</h2>
      <div class="setting-row">
        <label>Name
          <input id="subAdminName" type="text" placeholder="Sub admin name" />
        </label>
        <label>Username
          <input id="subAdminUsername" type="text" placeholder="login username" />
        </label>
        <label>Password
          <input id="subAdminPassword" type="password" placeholder="set password" />
        </label>
        <button id="addSubAdmin" class="primary" type="button">Add Sub Admin</button>
      </div>
      <div id="subAdminList" class="sub-admin-list"></div>
    </div>
  `;
  $("#workingDays").value = state.settings.workingDays;
  $("#saveSettings").addEventListener("click", () => {
    state.settings.workingDays = $("#workingDays").value;
    state.settings.lowAttendanceThreshold = Number($("#threshold").value);
    saveState();
    renderSettings();
  });
  $("#logoUpload").addEventListener("change", handleLogoUpload);
  $("#removeLogo")?.addEventListener("click", () => {
    state.settings.logoDataUrl = "";
    saveState();
    applyLogo();
    renderSettings();
  });
  $("#addSubAdmin").addEventListener("click", addSubAdmin);
  renderSubAdmins();
}

function handleLogoUpload(event) {
  const file = event.target.files?.[0];
  if (!file) return;
  const reader = new FileReader();
  reader.addEventListener("load", () => {
    state.settings.logoDataUrl = reader.result;
    saveState();
    applyLogo();
    renderSettings();
  });
  reader.readAsDataURL(file);
}

function applyLogo() {
  ["loginLogo", "sidebarLogo"].forEach((id) => {
    const image = document.getElementById(id);
    if (!image) return;
    image.classList.toggle("hidden", !state.settings.logoDataUrl);
    if (state.settings.logoDataUrl) image.src = state.settings.logoDataUrl;
  });
}

function addSubAdmin() {
  const name = $("#subAdminName").value.trim();
  const username = $("#subAdminUsername").value.trim().toLowerCase();
  const password = $("#subAdminPassword").value.trim();
  if (!name || !username || !password) {
    window.alert("Please enter sub admin name, username, and password.");
    return;
  }
  if (state.settings.subAdmins.some((admin) => admin.username.toLowerCase() === username)) {
    window.alert("That sub admin username already exists.");
    return;
  }
  state.settings.subAdmins.push({
    id: window.crypto && crypto.randomUUID ? crypto.randomUUID() : `sub-admin-${Date.now()}`,
    name,
    username,
    password
  });
  saveState();
  renderSettings();
}

function renderSubAdmins() {
  const list = $("#subAdminList");
  list.innerHTML = "";
  if (!state.settings.subAdmins.length) {
    list.append(el("p", "", "No sub admins added yet."));
    return;
  }
  state.settings.subAdmins.forEach((admin) => {
    const row = el("div", "approval-row");
    row.innerHTML = `<div><strong>${admin.name}</strong><p>${admin.username}</p></div>`;
    const remove = el("button", "danger", "Remove");
    remove.type = "button";
    remove.addEventListener("click", () => removeSubAdmin(admin.id));
    row.append(remove);
    list.append(row);
  });
}

function removeSubAdmin(id) {
  const admin = state.settings.subAdmins.find((item) => item.id === id);
  if (!admin) return;
  if (!window.confirm(`Remove sub admin ${admin.name}?`)) return;
  state.settings.subAdmins = state.settings.subAdmins.filter((item) => item.id !== id);
  saveState();
  renderSettings();
}

function findAdminLogin(username, password) {
  if (password === state.settings.adminPassword && !username) return { name: "Main Admin" };
  if (password === state.settings.adminPassword && username === "admin") return { name: "Main Admin" };
  return state.settings.subAdmins.find((admin) => admin.username.toLowerCase() === username && admin.password === password);
}

function updateClock() {
  const now = new Date();
  const seconds = now.getSeconds();
  const minutes = now.getMinutes();
  const hours = now.getHours() % 12;
  const secondDeg = seconds * 6;
  const minuteDeg = minutes * 6 + seconds * 0.1;
  const hourDeg = hours * 30 + minutes * 0.5;
  ["login", "dash"].forEach((prefix) => {
    const hour = document.getElementById(`${prefix}Hour`);
    const minute = document.getElementById(`${prefix}Minute`);
    const second = document.getElementById(`${prefix}Second`);
    if (hour) hour.style.transform = `translateX(-50%) rotate(${hourDeg}deg)`;
    if (minute) minute.style.transform = `translateX(-50%) rotate(${minuteDeg}deg)`;
    if (second) second.style.transform = `translateX(-50%) rotate(${secondDeg}deg)`;
  });
  const time = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: true });
  $("#loginDigitalClock").textContent = time;
  $("#digitalClock").textContent = time;
}

document.querySelectorAll("[data-auth-tab]").forEach((tab) => tab.addEventListener("click", () => setAuthTab(tab.dataset.authTab)));

$("#adminLogin").addEventListener("submit", (event) => {
  event.preventDefault();
  pulseLogin();
  const username = $("#adminUsername").value.trim().toLowerCase();
  const password = $("#adminPassword").value.trim();
  const admin = findAdminLogin(username, password);
  if (admin) login("admin", admin);
  else setNotice("Admin username or password did not match.");
});

$("#staffLogin").addEventListener("submit", (event) => {
  event.preventDefault();
  pulseLogin();
  const username = $("#staffUsername").value.trim().toLowerCase();
  const person = state.staff.find((item) => item.username.toLowerCase() === username);
  if (!person) return setNotice("No registration found for that username.");
  if (person.status !== "approved") return setNotice(`Registration status: ${person.status}.`);
  login("staff", person);
});

$("#registerForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const username = $("#regUsername").value.trim().toLowerCase();
  if (state.staff.some((person) => person.username.toLowerCase() === username)) {
    setNotice("That username is already registered.");
    return;
  }
  state.staff.push({
    id: window.crypto && crypto.randomUUID ? crypto.randomUUID() : `staff-${Date.now()}`,
    name: $("#regName").value.trim(),
    username,
    role: $("#regRole").value.trim(),
    email: $("#regEmail").value.trim(),
    phone: $("#regPhone").value.trim(),
    status: "pending",
    registeredAt: new Date().toISOString()
  });
  saveState();
  event.target.reset();
  setNotice("Registration sent. Admin approval is required before login.");
});

$("#logoutBtn").addEventListener("click", logout);
$("#themeToggle").addEventListener("click", () => document.body.classList.toggle("dark"));

updateClock();
applyLogo();
setInterval(updateClock, 1000);
